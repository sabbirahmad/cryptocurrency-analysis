1) Install Python3 and Jupiter notebook
2) copy the dataset 'crypto-markets.csv' in same directory
2) Install following using pip
	a) gpflow -> pip install gpflow
	b) Keras -> pip install Keras
	c) tensorflow - > pip install tensorflow
4) Run all cell commands
5) As the notebook is huge, it may fail in between due to memory error. If it fails, just select that cell and run All below option

